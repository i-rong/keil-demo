#include <stdbool.h>
#include <stdlib.h>
#include "checksum.h"

uint16_t crc_modbus( const unsigned char *input_str, size_t num_bytes );
