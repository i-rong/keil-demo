#include "test.h"

int main(void) {  
		systemInit();
		
		while(1) {
				//test1();
        //test2();	
				test3();
		}
}
