void systeminit();
void test0();