#include "user.h"
#include "test.h"

int main(void)
{ 
	systeminit();
	while(1) {
		test0();
	}
}
