#ifndef __SHT30_H
#define __SHT30_H

#endif