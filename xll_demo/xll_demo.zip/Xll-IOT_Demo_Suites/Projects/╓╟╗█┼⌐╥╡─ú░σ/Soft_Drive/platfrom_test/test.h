#ifndef _TEST_H
#define _TEST_H

#ifdef cplusplus
 extern "C" {
#endif
	 
#include "gd32f4xx.h"	 
	 
void system_init(void);
void test(void);


	 
#ifdef cplusplus
}
#endif

#endif	 


