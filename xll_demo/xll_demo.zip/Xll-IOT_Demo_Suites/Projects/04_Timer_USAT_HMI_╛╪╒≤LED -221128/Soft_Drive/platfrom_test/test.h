#ifndef _TEST_H
#define _TEST_H

#ifdef cplusplus
 extern "C" {
#endif
	 
#include "gd32f4xx.h"	 
	 
void system_init(void);
void test1(void);
void test2(void);

	 
#ifdef cplusplus
}
#endif

#endif	 


